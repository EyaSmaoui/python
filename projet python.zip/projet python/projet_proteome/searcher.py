# searcher.py
def search_words_in_proteome(words, sequences, count_occurrences=False, callback=None):
    results={}
    total=len(words)
    for i,w in enumerate(words):
        count=0
        for seq in sequences.values():
            if w in seq:
                count += seq.count(w) if count_occurrences else 1
        results[w]=count
        if callback:
            callback(i+1, total, w, count)
    return results

def find_most_frequent_word(results, total_sequences):
    best = max(results, key=results.get)
    count = results[best]
    pct = (count/total_sequences)*100 if total_sequences else 0
    return best, count, pct
