# main.py
from proteome import read_words, read_sequences
from searcher import search_words_in_proteome, find_most_frequent_word

def main():
    words=read_words("english-common-words.txt")
    seqs=read_sequences("human-proteome.fasta")
    results=search_words_in_proteome(words,seqs)
    best,count,pct=find_most_frequent_word(results,len(seqs))
    print(best,count,pct)

if __name__=="__main__":
    main()
