# gui.py
import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter import ttk
import threading, csv
from proteome import read_words, read_sequences
from searcher import search_words_in_proteome, find_most_frequent_word

def select_file(entry):
    filename = filedialog.askopenfilename()
    if filename:
        entry.delete(0, tk.END)
        entry.insert(0, filename)

def gui_app():
    root=tk.Tk()
    root.title("Analyse du proteome")

    tk.Label(root,text="Fichier mots:").grid(row=0,column=0)
    entry_words=tk.Entry(root,width=50); entry_words.grid(row=0,column=1)
    tk.Button(root,text="Parcourir",command=lambda:select_file(entry_words)).grid(row=0,column=2)

    tk.Label(root,text="Fichier FASTA:").grid(row=1,column=0)
    entry_fasta=tk.Entry(root,width=50); entry_fasta.grid(row=1,column=1)
    tk.Button(root,text="Parcourir",command=lambda:select_file(entry_fasta)).grid(row=1,column=2)

    progress=ttk.Progressbar(root,length=400,mode='determinate')
    progress.grid(row=2,column=0,columnspan=3,pady=10)

    text=tk.Text(root,width=80,height=20); text.grid(row=3,column=0,columnspan=3)

    state={"results":{}}

    def update_gui(i,total,word,count):
        progress['value']=(i/total)*100
        if count>0:
            text.insert(tk.END,f"{word} trouvé dans {count} séquences\n")
            text.see(tk.END)

    def worker():
        try:
            text.insert(tk.END,"Chargement...\n")
            words=read_words(entry_words.get())
            seqs=read_sequences(entry_fasta.get())
            results=search_words_in_proteome(words,seqs,False,callback=update_gui)
            state['results']=results
            best,count,pct=find_most_frequent_word(results,len(seqs))
            text.insert(tk.END,f"Mot le plus fréquent: {best} ({count} seq, {pct:.2f}%)\n")
        except Exception as e:
            messagebox.showerror("Erreur",str(e))

    def run_thread():
        threading.Thread(target=worker).start()

    def export_csv():
        if not state['results']:
            messagebox.showwarning("Aucun résultat","Lancez d'abord une analyse.")
            return
        filename=filedialog.asksaveasfilename(defaultextension=".csv")
        if filename:
            with open(filename,"w",newline="",encoding="utf-8") as f:
                w=csv.writer(f)
                w.writerow(["Mot","Nb séquences"])
                for k,v in state['results'].items():
                    w.writerow([k,v])
            messagebox.showinfo("OK","Export terminé.")

    tk.Button(root,text="Lancer analyse",command=run_thread,bg="green",fg="white").grid(row=4,column=1,pady=10)
    tk.Button(root,text="Exporter CSV",command=export_csv).grid(row=5,column=1)
    root.mainloop()

if __name__=="__main__":
    gui_app()
