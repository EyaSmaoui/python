# proteome.py
from typing import Dict, Generator, Tuple, List

def read_words(filename: str, min_len: int = 3) -> List[str]:
    words = []
    with open(filename, 'r', encoding='utf-8') as fh:
        for line in fh:
            w = line.strip()
            if w and len(w)>=min_len:
                words.append(w.upper())
    return words

def read_sequences(filename: str) -> Dict[str,str]:
    seqs={}
    current_id=None
    parts=[]
    with open(filename,'r',encoding='utf-8') as fh:
        for raw in fh:
            line=raw.strip()
            if not line: continue
            if line.startswith('>'):
                if current_id is not None:
                    seqs[current_id]=''.join(parts).upper()
                current_id=line[1:].split()[0]
                parts=[]
            else:
                parts.append(line)
        if current_id is not None:
            seqs[current_id]=''.join(parts).upper()
    return seqs

def stream_sequences(filename: str) -> Generator[Tuple[str,str],None,None]:
    current_id=None
    parts=[]
    with open(filename,'r',encoding='utf-8') as fh:
        for raw in fh:
            line=raw.strip()
            if not line: continue
            if line.startswith('>'):
                if current_id is not None:
                    yield current_id, ''.join(parts).upper()
                current_id=line[1:].split()[0]
                parts=[]
            else:
                parts.append(line)
        if current_id is not None:
            yield current_id, ''.join(parts).upper()
